# Week 1 Project Report: Data Analytics Strategic Plan

**Prepared by:** Anuska Dhar

## Objective
Demonstrate a practical Python-based analytics workflow that turns transaction-level data into business KPIs and strategic questions.

## Dataset
The project uses a synthetic retail transaction dataset with 1,200 initial rows. It intentionally includes a small number of data-quality issues to demonstrate profiling and cleaning. It is not real business data.

## Method
- Ingest CSV data with pandas.
- Inspect missing values and duplicate order IDs.
- Standardize text, parse dates and numeric columns, remove duplicate orders and rows missing essential fields.
- Calculate revenue, estimated profit, order count, average order value, and units sold.
- Aggregate revenue by month, product, and region.
- Export cleaned data, a text KPI report, and charts.

## Results
The script generates the current metrics in `outputs/kpi_summary.txt`. The results are synthetic and should be used only to demonstrate the workflow, not as factual claims about a real company.

## Strategic interpretation
1. Review the monthly revenue chart to identify periods that may require inventory or staffing adjustments.
2. Compare product and regional revenue before deciding where to focus marketing or merchandising.
3. Investigate missing fields and duplicate order identifiers with the system owner.
4. Establish a baseline and run a controlled pilot before claiming that an intervention improved business outcomes.

## Limitations
The cost values are simulated, the dataset is fictional, and the analysis is descriptive rather than causal. The project does not claim that correlation proves why revenue changed.

## Future enhancements
- Add a forecasting model and evaluate it against a naïve baseline.
- Build a dashboard using Streamlit or Power BI.
- Add automated data-quality tests and a scheduled refresh.
- Repeat the analysis with a real dataset only when its use is authorized.


## KPI output snapshot

```text
RETAIL SALES ANALYTICS — KPI SUMMARY
Synthetic demonstration data; not real company results.

Clean transactions: 1,198
Unique orders: 1,198
Total revenue: $100,474.62
Estimated profit: $39,904.00
Units sold: 2,968
Average order value: $83.87
Critical-field completeness after cleaning: 100.0%
Duplicate order IDs removed: 1
Rows removed for missing essential fields: 1

TOP PRODUCTS BY REVENUE
product
Headphones        28341.55
Keyboard          19428.16
Webcam            16096.51
USB-C Hub         13618.32
Wireless Mouse    12300.62

STRATEGIC INTERPRETATION
- Use monthly revenue trends to support inventory and staffing discussions.
- Compare product and regional results before allocating promotion budgets.
- Validate data-quality issues with source-system owners before operational use.

```
