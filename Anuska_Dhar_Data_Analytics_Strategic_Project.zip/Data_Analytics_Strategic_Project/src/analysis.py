from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "retail_sales_raw.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def main():
    df = pd.read_csv(DATA_PATH)
    print("RAW DATA SHAPE:", df.shape)
    print("\nMissing values before cleaning:\n", df.isna().sum())
    duplicate_count = int(df["order_id"].duplicated().sum())
    print(f"\nDuplicate order IDs before cleaning: {duplicate_count}")

    # Standardize text fields and parse types.
    for col in ["product", "category", "region", "sales_channel", "customer_id", "order_id"]:
        df[col] = df[col].astype("string").str.strip()
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    for col in ["quantity", "unit_price", "discount_rate", "revenue", "estimated_cost"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Remove duplicate IDs, then remove records missing essential business fields.
    df = df.drop_duplicates(subset=["order_id"], keep="first")
    essential = ["order_id", "order_date", "product", "quantity", "revenue"]
    before = len(df)
    df = df.dropna(subset=essential).copy()
    removed_missing_essential = before - len(df)

    # Basic validation and derived fields.
    df = df[(df["quantity"] > 0) & (df["revenue"] >= 0)].copy()
    df["estimated_profit"] = df["revenue"] - df["estimated_cost"]
    df["month"] = df["order_date"].dt.to_period("M").astype(str)
    df["region"] = df["region"].fillna("Unknown")
    df["category"] = df["category"].fillna("Unknown")
    df["sales_channel"] = df["sales_channel"].fillna("Unknown")

    # KPI calculations.
    order_count = int(df["order_id"].nunique())
    total_revenue = float(df["revenue"].sum())
    total_profit = float(df["estimated_profit"].sum())
    units_sold = float(df["quantity"].sum())
    aov = total_revenue / order_count if order_count else 0
    completeness = 100 * (1 - df[["order_date", "product", "quantity", "revenue"]].isna().sum().sum()
                           / (len(df) * 4)) if len(df) else 0

    kpis = [
        ("Clean transactions", f"{len(df):,}"),
        ("Unique orders", f"{order_count:,}"),
        ("Total revenue", f"${total_revenue:,.2f}"),
        ("Estimated profit", f"${total_profit:,.2f}"),
        ("Units sold", f"{units_sold:,.0f}"),
        ("Average order value", f"${aov:,.2f}"),
        ("Critical-field completeness after cleaning", f"{completeness:.1f}%"),
        ("Duplicate order IDs removed", str(duplicate_count)),
        ("Rows removed for missing essential fields", str(removed_missing_essential)),
    ]
    summary_path = OUT / "kpi_summary.txt"
    with summary_path.open("w", encoding="utf-8") as f:
        f.write("RETAIL SALES ANALYTICS — KPI SUMMARY\n")
        f.write("Synthetic demonstration data; not real company results.\n\n")
        for label, value in kpis:
            f.write(f"{label}: {value}\n")
        f.write("\nTOP PRODUCTS BY REVENUE\n")
        f.write(df.groupby("product")["revenue"].sum().sort_values(ascending=False).head(5).to_string())
        f.write("\n\nSTRATEGIC INTERPRETATION\n")
        f.write("- Use monthly revenue trends to support inventory and staffing discussions.\n")
        f.write("- Compare product and regional results before allocating promotion budgets.\n")
        f.write("- Validate data-quality issues with source-system owners before operational use.\n")
    df.to_csv(OUT / "cleaned_sales.csv", index=False)

    # Chart 1: monthly revenue
    monthly = df.groupby("month", as_index=False)["revenue"].sum()
    plt.figure(figsize=(10, 5))
    plt.plot(monthly["month"], monthly["revenue"], marker="o")
    plt.title("Monthly Revenue")
    plt.xlabel("Month")
    plt.ylabel("Revenue ($)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(OUT / "monthly_revenue.png", dpi=160)
    plt.close()

    # Chart 2: revenue by product
    product = df.groupby("product")["revenue"].sum().sort_values()
    plt.figure(figsize=(9, 5))
    product.plot(kind="barh")
    plt.title("Revenue by Product")
    plt.xlabel("Revenue ($)")
    plt.ylabel("Product")
    plt.tight_layout()
    plt.savefig(OUT / "revenue_by_product.png", dpi=160)
    plt.close()

    # Chart 3: revenue by region
    region = df.groupby("region")["revenue"].sum().sort_values(ascending=False)
    plt.figure(figsize=(8, 5))
    region.plot(kind="bar")
    plt.title("Revenue by Region")
    plt.xlabel("Region")
    plt.ylabel("Revenue ($)")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(OUT / "revenue_by_region.png", dpi=160)
    plt.close()

    print("\n".join(f"{k}: {v}" for k, v in kpis))
    print(f"\nAnalysis complete. Outputs saved to: {OUT}")

if __name__ == "__main__":
    main()
